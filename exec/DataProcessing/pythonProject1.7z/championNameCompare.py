
from urllib import parse
import pprint
import time

import json
import os
import pymysql

pp = pprint.PrettyPrinter(indent=4)

filename = 'G:/Downloads/싸피/잡것/9월/dragontail-12.17.1/12.17.1/data/ko_KR/champion.json'

filedata = {}
with open(filename, mode='r', encoding='utf-8') as infile:
    filedata = json.load(infile);

championDatas = filedata.get("data")
championNames = {}
for key in championDatas.keys() :
    championNames[key] = {}
    championNames[key]["name"] = championDatas.get(key).get("name")
    championNames[key]["key"] = championDatas.get(key).get("key")
    championNames[key]["id"] = championDatas.get(key).get("id")

pp.pprint(championNames)

with open("G:/Downloads/싸피/잡것/9월/championEnAndKrNames.json", mode='w', encoding='utf-8') as outfile:
    json.dump(championNames, outfile,  ensure_ascii=False )