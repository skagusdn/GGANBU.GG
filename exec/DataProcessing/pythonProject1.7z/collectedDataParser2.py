from urllib import parse
import pprint
import time

import json
import os
import pymysql
from datetime import datetime

pp = pprint.PrettyPrinter(indent=4)

folderName = "G:/Downloads/싸피/잡것/9월/result/processedData"
resultSavePath = "G:/Downloads/싸피/잡것/9월/result/doubleProcessedData"

file_list = os.listdir(folderName)

championDataPath = "G:/Downloads/싸피/잡것/9월/championEnAndKrNames.json"
championData = {}
with open(championDataPath, mode="r", encoding="utf-8") as infile:
    championData = json.load(infile)


roughTiers = ["high", "mid", "low"]
positions = ["TOP", "JUNGLE", "MIDDLE", "BOTTOM", "UTILITY"]
keyTypes = ["championBans", "singleRelationTeam", "singleRelationEnemy", "noRelationCommon", "singleRelationRival"]
championIds = []

for champKey in championData.keys():
    championIds.append(championData[champKey]["key"])

championStatistics = {}

with open(folderName + "/championStatistics.json", mode='r') as infile:
    championStatistics = json.load(infile)

championBansDatas = {}
singleRelationTeamDatas = {}
singleRelationEnemyDatas = {}
noRelationCommonDatas = {}
singleRelationRivalDatas = {}
matchBansDatas = {}

championBansResult = []
singleRelationTeamResult = []
singleRelationEnemyResult = []
noRelationCommonResult = []
singleRelationRivalResult = []
matchBansResult = []




for roughTier in championStatistics.keys():
    statisticsPerTier = {}
    statisticsPerTier = championStatistics.get(roughTier)

    # tierBans
    matchBansDatas = statisticsPerTier.get("matchBans")
    dataOne = {}
    dataOne["roughTier"] = roughTier
    dataOne["data"] = matchBansDatas
    matchBansResult.append(dataOne)
    #

    perChampion = {}
    perChampion = statisticsPerTier.get("perChampion")

    for champion1 in perChampion.keys():
        champion1Data = {}
        champion1Data = perChampion.get(champion1)
        if champion1Data is None:
            continue

        for position1 in champion1Data.keys():
            rootData = {}
            rootData = champion1Data.get(position1)
            if rootData is None:
                continue

            for keyType in keyTypes:


                #championBans
                if keyType == "championBans":
                    championBansData = rootData.get(keyType)
                    if championBansData is None:
                        continue

                    dataOne = {}
                    dataOne["roughTier"] = roughTier
                    dataOne["champion1"] = champion1
                    dataOne["position1"] = position1
                    dataOne["data"] = championBansData
                    championBansResult.append(dataOne)

                #singleRelationTeam & singleRelationEnemy
                if keyType == "singleRelationTeam" or keyType == "singleRelationEnemy":
                    singleRelationData = rootData.get(keyType)
                    if singleRelationData is None:
                        continue

                    for champion2 in singleRelationData.keys():
                        champion2Data = {}
                        champion2Data = singleRelationData.get(champion2)
                        if champion2Data is None:
                            continue

                        for position2 in positions:
                            data = {}
                            data = champion2Data.get(position2)
                            if data is None:
                                continue

                            dataOne = {}
                            dataOne["roughTier"] = roughTier
                            dataOne["champion1"] = champion1
                            dataOne["position1"] = position1
                            dataOne["champion2"] = champion2
                            dataOne["position2"] = position2

                            dataOne["data"] = data

                            if keyType == "singleRelationTeam":
                                singleRelationTeamResult.append(dataOne)
                            else:
                                singleRelationEnemyResult.append(dataOne)

                #singleRelationRival
                if keyType == "singleRelationRival":
                    singleRelationRivalData = {}
                    singleRelationRivalData = rootData.get(keyType)
                    if singleRelationRivalData is None:
                        continue

                    for champion2 in singleRelationRivalData.keys():
                        data = {}
                        data = singleRelationRivalData.get(champion2)
                        if data is None:
                            continue


                        dataOne = {}
                        dataOne["roughTier"] = roughTier
                        dataOne["champion1"] = champion1
                        dataOne["position1"] = position1
                        dataOne["champion2"] = champion2

                        dataOne["data"] = data

                        singleRelationRivalResult.append(dataOne)

                #noRelationCommon
                if keyType == "noRelationCommon":

                    noRelationCommonData = {}
                    noRelationCommonData = rootData.get("noRelationCommon")
                    if noRelationCommonData is None:
                        continue

                    data = {}
                    data = noRelationCommonData

                    dataOne = {}
                    dataOne["roughTier"] = roughTier
                    dataOne["champion1"] = champion1
                    dataOne["position1"] = position1

                    dataOne["data"] = data

                    noRelationCommonResult.append(dataOne)


with open(resultSavePath + "/matchBans/matchBansResult.json", mode='w') as outfile:
    json.dump(matchBansResult, outfile)

with open(resultSavePath + "/championBans/championBansResult.json", mode='w') as outfile:
    json.dump(championBansResult, outfile)

with open(resultSavePath + "/singleRelationTeam/singleRelationTeamResult.json", mode='w') as outfile:
    json.dump(singleRelationTeamResult, outfile)

with open(resultSavePath + "/singleRelationEnemy/singleRelationEnemyResult.json", mode='w') as outfile:
    json.dump(singleRelationEnemyResult, outfile)

with open(resultSavePath + "/noRelationCommon/noRelationCommonResult.json", mode='w') as outfile:
    json.dump(noRelationCommonResult, outfile)

with open(resultSavePath + "/singleRelationRival/singleRelationRivalResult.json", mode='w') as outfile:
    json.dump(singleRelationRivalResult, outfile)

print("complete")