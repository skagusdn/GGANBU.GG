from urllib import parse
import pprint
import time

import json
import os
import pymysql
from datetime import datetime

pp = pprint.PrettyPrinter(indent=4)

folderName = "G:/Downloads/싸피/잡것/9월/result/collectedDatas"
resultSavePath = "G:/Downloads/싸피/잡것/9월/result/processedData"

file_list = os.listdir(folderName)

championDataPath = "G:/Downloads/싸피/잡것/9월/championEnAndKrNames.json"
championData = {}
with open(championDataPath, mode="r", encoding="utf-8") as infile:
    championData = json.load(infile)


roughTiers = ["high", "mid", "low"]
positions = ["TOP", "JUNGLE", "MIDDLE", "BOTTOM", "UTILITY"]
keyTypes = ["championBans", "singleRelationTeam", "singleRelationEnemy", "noRelationCommon", "singleRelationRival"]
championIds = []

for champKey in championData.keys():
    championIds.append(championData[champKey]["key"])


def init_result_data(result_data):
    for tier in roughTiers :
        if tier not in result_data:
            result_data[tier] = {}

        if "perChampion" not in result_data[tier]:
            result_data[tier]["perChampion"] = {}
        if "matchBans" not in result_data[tier]:
            result_data[tier]["matchBans"] = {}

        for k in championData.keys():
            champion = championData[k]["key"]
            if champion not in result_data[tier]["perChampion"]:
                result_data[tier]["perChampion"][champion] = {}

            for pos in positions:
                if pos not in result_data[tier]["perChampion"][champion]:
                    result_data[tier]["perChampion"][champion][pos] = {}

                for _type in keyTypes:
                    if _type not in result_data[tier]["perChampion"][champion][pos]:
                        result_data[tier]["perChampion"][champion][pos][_type] = {}

    return result_data


theResultData = {}
with open(resultSavePath + "/championStatistics.json", mode='r', encoding='utf8') as infile:
    theResultData = json.load(infile)

theResultData = init_result_data(theResultData)

for file in file_list:

    dataLines = []
    with open(folderName + '/' + file, mode='r', encoding='utf-8') as infile:
        dataLines = infile.readlines()


## for handling error
    lineIdx = 0

    for line in dataLines:

        ###
        lineIdx += 1
        ###

        line = line.strip()
        keySplit = line.split("\t")[0].split("_")

        ##
        escapeFlag = False
        for kys in keySplit:
           if kys == '' :
                escapeFlag = True
                break
        if escapeFlag:
            continue
        ##
        values = line.split("\t")[1].split(" ")

        keyType = keySplit[0]

        if keyType == "singleRelationTeam" or keyType == "singleRelationEnemy":
            roughTier = keySplit[1]
            position1 = keySplit[2]
            champion1 = keySplit[3]
            position2 = keySplit[4]
            champion2 = keySplit[5]

            ##
            if roughTier not in roughTiers or position1 not in positions or position2 not in positions or champion1 not in championIds or champion2 not in championIds:
                print("something error1")
                continue
            ##

            resultVal = {}

            if champion2 not in theResultData[roughTier]['perChampion'][champion1][position1][keyType]:
                theResultData[roughTier]['perChampion'][champion1][position1][keyType][champion2] = {}
            if position2 not in theResultData[roughTier]['perChampion'][champion1][position1][keyType][champion2]:
                theResultData[roughTier]['perChampion'][champion1][position1][keyType][champion2][position2] = {}

            win1_ = 0
            matchNum1_ = 0

            for value in values:
                if value == "\n":
                    continue

                vk = value.split("_")[0]
                vv = int(value.split("_")[1])

                if vk == "win":
                    win1_ = vv
                elif vk == "matchNum":
                    matchNum1_ = vv

                if vk not in theResultData[roughTier]['perChampion'][champion1][position1][keyType][champion2][position2]:
                    theResultData[roughTier]['perChampion'][champion1][position1][keyType][champion2][position2][vk] = 0

                theResultData[roughTier]['perChampion'][champion1][position1][keyType][champion2][position2][vk] += vv

            #reverse
            if champion1 not in theResultData[roughTier]['perChampion'][champion2][position2][keyType]:
                theResultData[roughTier]['perChampion'][champion2][position2][keyType][champion1] = {}
            if position1 not in theResultData[roughTier]['perChampion'][champion2][position2][keyType][champion1]:
                theResultData[roughTier]['perChampion'][champion2][position2][keyType][champion1][position1] = {}

            if "win" not in theResultData[roughTier]['perChampion'][champion2][position2][keyType][champion1][position1]:
                theResultData[roughTier]['perChampion'][champion2][position2][keyType][champion1][position1]["win"] = 0
            if "matchNum" not in theResultData[roughTier]['perChampion'][champion2][position2][keyType][champion1][position1]:
                theResultData[roughTier]['perChampion'][champion2][position2][keyType][champion1][position1]["matchNum"] = 0

            theResultData[roughTier]['perChampion'][champion2][position2][keyType][champion1][position1]["win"] += matchNum1_ - win1_
            theResultData[roughTier]['perChampion'][champion2][position2][keyType][champion1][position1]["matchNum"] += matchNum1_

        elif keyType == "noRelationCommon":
            roughTier = keySplit[1]
            position1 = keySplit[2]
            champion1 = keySplit[3]

            ##
            if roughTier not in roughTiers or position1 not in positions or champion1 not in championIds :
                print("something error2")
                continue
            ##

            for value in values:
                if value == "\n":
                    continue

                vk = value.split("_")[0]
                vv = int(value.split("_")[1])

                if vk not in theResultData[roughTier]['perChampion'][champion1][position1][keyType]:
                    theResultData[roughTier]['perChampion'][champion1][position1][keyType][vk] = 0

                theResultData[roughTier]['perChampion'][champion1][position1][keyType][vk] += vv

        elif keyType == "singleRelationRival":
            roughTier = keySplit[1]
            position = keySplit[2]
            champion1 = keySplit[3]
            champion2 = keySplit[4]

            ##
            if roughTier not in roughTiers or position not in positions or champion1 not in championIds or champion2 not in championIds:
                print("something error3")
                continue
            ##

            if champion2 not in theResultData[roughTier]['perChampion'][champion1][position][keyType]:
                theResultData[roughTier]['perChampion'][champion1][position][keyType][champion2] = {}
            if "me" not in theResultData[roughTier]['perChampion'][champion1][position][keyType]:
                theResultData[roughTier]['perChampion'][champion1][position][keyType][champion2]["me"] = {}
            if "rival" not in theResultData[roughTier]['perChampion'][champion1][position][keyType]:
                theResultData[roughTier]['perChampion'][champion1][position][keyType][champion2]["rival"] = {}

            #reverse
            if champion1 not in theResultData[roughTier]['perChampion'][champion2][position][keyType]:
                theResultData[roughTier]['perChampion'][champion2][position][keyType][champion1] = {}
            if "me" not in theResultData[roughTier]['perChampion'][champion2][position][keyType][champion1]:
                theResultData[roughTier]['perChampion'][champion2][position][keyType][champion1]["me"] = {}
            if "rival" not in theResultData[roughTier]['perChampion'][champion2][position][keyType][champion1]:
                theResultData[roughTier]['perChampion'][champion2][position][keyType][champion1]["rival"] = {}

            aboutChampion1 = {}
            aboutChampion2 = {}

            for value in values:
                if value == "\n":
                    continue

                vk = value.split("_")[0]
                vv = int(value.split("_")[1])

                champIdx = vk[-1]
                vk = vk[0:-1]
                ##
                vk = vk.replace("-", "")

                if champIdx == "1":
                    aboutChampion1[vk] = vv
                else:
                    aboutChampion2[vk] = vv

            for value in values:
                if value == "\n":
                    continue

                vk = value.split("_")[0]
                champIdx = vk[-1]
                vk = vk[0:-1]
                ##
                vk = vk.replace("-", "")

                if vk not in  theResultData[roughTier]['perChampion'][champion1][position][keyType][champion2]["me"]:
                    theResultData[roughTier]['perChampion'][champion1][position][keyType][champion2]["me"][vk] = 0

                theResultData[roughTier]['perChampion'][champion1][position][keyType][champion2]["me"][vk] += aboutChampion1[vk]

                if vk not in  theResultData[roughTier]['perChampion'][champion1][position][keyType][champion2]["rival"]:
                    theResultData[roughTier]['perChampion'][champion1][position][keyType][champion2]["rival"][vk] = 0

                theResultData[roughTier]['perChampion'][champion1][position][keyType][champion2]["rival"][vk] += aboutChampion2[vk]

            #reverse
            for value in values:
                if value == "\n":
                    continue

                vk = value.split("_")[0]
                champIdx = vk[-1]
                vk = vk[0:-1]
                ##
                vk = vk.replace("-", "")

                if vk not in theResultData[roughTier]['perChampion'][champion2][position][keyType][champion1]["me"]:
                    theResultData[roughTier]['perChampion'][champion2][position][keyType][champion1]["me"][vk] = 0

                theResultData[roughTier]['perChampion'][champion2][position][keyType][champion1]["me"][vk] += \
                aboutChampion2[vk]

                if vk not in theResultData[roughTier]['perChampion'][champion2][position][keyType][champion1]["rival"]:
                    theResultData[roughTier]['perChampion'][champion2][position][keyType][champion1]["rival"][vk] = 0

                theResultData[roughTier]['perChampion'][champion2][position][keyType][champion1]["rival"][vk] += \
                aboutChampion1[vk]

        elif keyType == "championBans":
            roughTier = keySplit[1]
            position1 = keySplit[2]
            champion1 = keySplit[3]

            ##
            if roughTier not in roughTiers or position1 not in positions  or champion1 not in championIds :
                print("something error4")
                continue
            ##

            for value in values:
                value = value.strip()
                if value == "\n":
                    continue

                vk = value.split("_")[0]
                vv = int(value.split("_")[1])

                ####
                try:
                    if vk not in theResultData[roughTier]['perChampion'][champion1][position1][keyType]:
                        theResultData[roughTier]['perChampion'][champion1][position1][keyType][vk] = 0
                except KeyError:
                    break
                    # print(roughTier)
                    # print(champion1)
                    # print(position1)
                    # print(keyType)
                    # print(vk)
                    # print(keySplit)
                    # print("에반데")
                    # print(lineIdx)
                    # print(file)
                    # exit(0)
                #####



                theResultData[roughTier]['perChampion'][champion1][position1][keyType][vk] += vv

        elif keyType == "matchBans":
            roughTier = keySplit[1]

            ##
            if roughTier == 'mid':
                print("found mid matchBans!")
            ##

            ##
            if roughTier not in roughTiers :
                print("something error5")
                continue
            ##

            for value in values:
                if value == "\n":
                    continue

                vk = value.split("_")[0]
                vv = int(value.split("_")[1])

                if vk not in theResultData[roughTier][keyType]:
                    theResultData[roughTier][keyType][vk] = 0
                theResultData[roughTier][keyType][vk] += vv


with open(resultSavePath + "/championStatistics.json", mode='w', encoding='utf8') as outfile:
    json.dump(theResultData, outfile)


print("complete")
